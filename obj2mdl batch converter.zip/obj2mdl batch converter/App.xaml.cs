﻿using System.Windows;
namespace obj2mdl_batch_converter
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }
}
